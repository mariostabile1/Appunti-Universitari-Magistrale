# Protocolli MAC — Mobile and Cyber-Physical Systems
> **Corso:** Mobile and Cyber-Physical Systems — Prof. Stefano Chessa  
> **Argomento:** Medium Access Control (MAC) con efficienza energetica

---

## Indice
1. [Linee guida di progettazione](#1-linee-guida-di-progettazione)
2. [Sincronizzazione: S-MAC](#2-sincronizzazione-s-mac)
   - [Meccanismo di sincronizzazione](#21-meccanismo-di-sincronizzazione)
   - [Accesso al canale e collisioni](#22-accesso-al-canale-e-collisioni)
   - [Latenza in reti multi-hop](#23-latenza-in-reti-multi-hop)
   - [Mantenimento della sincronizzazione](#24-mantenimento-della-sincronizzazione)
3. [Preamble Sampling: B-MAC](#3-preamble-sampling-b-mac)
   - [Funzionamento](#31-funzionamento)
   - [Overhead del Low-Power Listening](#32-overhead-del-low-power-listening)
   - [Modellazione della durata di vita](#33-modellazione-della-durata-di-vita)
   - [Punti di forza e debolezze](#34-punti-di-forza-e-debolezze)
4. [Evoluzione di B-MAC: X-MAC e BoX-MAC](#4-evoluzione-di-b-mac-x-mac-e-box-mac)
   - [X-MAC](#41-x-mac)
   - [BoX-MAC](#42-box-mac)
5. [Polling](#5-polling)
6. [Esercizi e Domande](#6-esercizi-e-domande)
7. [Riferimenti bibliografici](#7-riferimenti-bibliografici)

---

## 1. Linee guida di progettazione

Nei sistemi wireless a bassa potenza (come le reti di sensori), il protocollo MAC non si limita a gestire l'**arbitraggio del canale** (chi trasmette quando), ma deve anche perseguire l'**efficienza energetica**. Questo è il requisito dominante in scenari dove i nodi sono alimentati a batteria.

I due obiettivi principali sono:
- **Ridurre il duty cycle radio** — la radio è il componente che consuma più energia; tenerla spenta il più possibile è fondamentale.
- **Mantenere la connettività della rete** — la rete deve rimanere funzionale nonostante i periodi di sleep.

Esiste un **trade-off** ineludibile: abbassare il duty cycle migliora l'efficienza energetica, ma aumenta la **latenza** e riduce la **banda** disponibile.

### Le tre strategie principali

| Approccio | Protocollo | Idea chiave |
|---|---|---|
| **Sincronizzazione** | S-MAC, IEEE 802.15.4 | I nodi si svegliano insieme in finestre temporali concordate |
| **Preamble sampling** | B-MAC, X-MAC, BoX-MAC | Il trasmettitore invia un lungo preambolo, il ricevitore campiona periodicamente |
| **Polling** | Bluetooth, IEEE 802.15.4 | Un nodo master convoca i nodi slave tramite beacon |

---

## 2. Sincronizzazione: S-MAC

**S-MAC** (*Sensor-MAC*) è un protocollo MAC per reti wireless multi-hop sviluppato per TinyOS e disponibile sulle piattaforme **Mica motes** (Iris, Tmote, ecc.). Il principio fondamentale è la **sincronizzazione locale** tra nodi vicini: non esiste un'unica sincronizzazione globale della rete, ma ciascun nodo si coordina solo con i propri vicini diretti.

L'idea di base è semplice: se i nodi adiacenti si svegliano nello stesso momento, possono comunicare durante quella finestra temporale comune, e poi dormire per il resto del tempo. Questo riduce drasticamente il consumo energetico della radio.

> 💡 **Nota:** S-MAC è anche un protocollo di **organizzazione della rete**, non solo di accesso al mezzo, perché definisce implicitamente la topologia temporale della comunicazione.

### 2.1 Meccanismo di sincronizzazione

Ogni nodo alterna **periodi di ascolto (listen)** e **periodi di sleep**. Durante il sleep, il nodo spegne la radio e non può rilevare messaggi in arrivo. La sincronizzazione avviene tramite frame speciali chiamati **SYNC frames**, trasmessi periodicamente in broadcast locale.

Un SYNC frame contiene lo **schedule del nodo**, ovvero le informazioni sui suoi periodi di sleep/wakeup. La logica di adozione dello schedule è la seguente:

```
SE il nodo rileva vicini con un periodo di ascolto già definito
    → adotta lo stesso periodo (si sincronizza ad essi)
ALTRIMENTI
    → sceglie autonomamente il proprio periodo
    → lo comunica ai vicini tramite SYNC frames
```

Un nodo può anche **cambiare il proprio schedule** se si accorge che nessun altro nodo condivide il suo schedule attuale.

![Diagramma temporale S-MAC — Nodi A, B, C con periodi di attività sovrapposti](mac_notes_img/smac_timing_diagram.png)
*Fig. 1 — I nodi adiacenti sincronizzano i propri periodi di attività (rosso). Il nodo B si sovrappone sia con A che con C.*

Come si vede dal diagramma, i nodi adiacenti (A↔B e B↔C) devono avere periodi di attività sovrapposti per poter comunicare. Notare che A e C potrebbero avere schedule diversi tra loro — è sufficiente che entrambi si sovrappongano con B.

### 2.2 Accesso al canale e collisioni

I frame vengono trasmessi **durante il periodo di ascolto del ricevitore**. Prima di trasmettere, il nodo esegue un **carrier sense** (ascolto del canale) per verificare che sia libero. Se il canale è occupato, il frame viene rimandato al **periodo successivo**.

Per evitare le collisioni, S-MAC usa il meccanismo **RTS/CTS** ereditato da IEEE 802.11, che funziona così:
1. Il trasmettitore invia un **RTS** (Request To Send)
2. Il ricevitore risponde con un **CTS** (Clear To Send)
3. Solo dopo il CTS inizia la trasmissione del frame dati

![Struttura dei frame S-MAC con periodo Sync e periodo Data](mac_notes_img/smac_frame_struct.png)
*Fig. 2 — Struttura temporale di un periodo S-MAC. A = periodo di attività, T = periodo totale (A + sleep). Il frame SYNC precede il frame dati.*

**Adaptive Duty Cycle:** S-MAC include un'ottimizzazione chiamata *adaptive listen*. Se un nodo "sente" un RTS o un CTS (anche se non è il destinatario diretto), mantiene la radio accesa fino alla fine della trasmissione corrente. Questo perché potrebbe essere il **prossimo hop** della comunicazione e in tal caso non perderà il pacchetto.

![Consumo energetico aggregato su percorso a 10 hop](mac_notes_img/smac_energy_graph.png)
*Fig. 3 — Consumo energetico aggregato su un percorso di 10 hop. Il duty cycle al 10% riduce drasticamente il consumo rispetto al caso senza sleep (curva superiore). L'adaptive listen migliora ulteriormente.*

### 2.3 Latenza in reti multi-hop

La latenza è il tallone d'Achille di S-MAC. Quando un pacchetto deve attraversare **più hop**, ad ogni salto può essere necessario **aspettare il prossimo periodo di ascolto** del nodo intermedio. Nel caso peggiore:

$$\text{Latenza totale} = N_{\text{hop}} \times T_{\text{periodo}}$$

dove $T_{\text{periodo}}$ è la durata di un intero periodo sleep+listen.

![Diagramma latenza multi-hop S-MAC — Nodi A, B, C, D, E, F](mac_notes_img/smac_latency_diagram.png)
*Fig. 4 — Propagazione di un pacchetto lungo un percorso A→B→C→D→E→F. Ogni nodo attende il proprio periodo di ascolto prima di ritrasmettere. La latenza totale è indicata dalla barra rossa in cima.*

Questa latenza è **mitigata** (ma non eliminata) se più nodi convergono verso lo stesso schedule: in quel caso non c'è attesa tra hop consecutivi. Tuttavia questa convergenza non è garantita dalla topologia.

![Grafico latenza media per hop al variare del numero di hop](mac_notes_img/smac_latency_graph.png)
*Fig. 5 — Latenza media per hop al crescere del numero di hop. Il duty cycle al 10% senza adaptive listen scala linearmente e in modo sfavorevole. L'adaptive listen abbatte significativamente la latenza.*

### 2.4 Mantenimento della sincronizzazione

Mantenere la sincronizzazione nel tempo è complesso per due ragioni:

1. **Clock drift** — gli orologi dei nodi non sono perfetti e si desincronizzano gradualmente. I SYNC frame periodici servono proprio a riallinearli.
2. **Conflitti topologici** — a seconda della topologia, un nodo potrebbe avere vicini con schedule incompatibili (es. nodo "di bordo" tra due cluster con schedule diversi). In questo caso S-MAC prevede un meccanismo per cui il nodo può **cambiare schedule** adattandosi alla maggioranza dei vicini.

---

## 3. Preamble Sampling: B-MAC

**B-MAC** (*Berkeley MAC*) è un protocollo MAC alternativo a S-MAC, anch'esso disponibile per TinyOS e mica motes. La differenza fondamentale è che **non usa la sincronizzazione** tra i nodi: il trasmettitore può inviare un pacchetto in qualsiasi momento, senza preoccuparsi di aspettare un periodo di ascolto condiviso.

Come è possibile? Tramite il meccanismo del **preamble sampling**, basato sulla modalità **Low-Power Listening (LPL)**.

### 3.1 Funzionamento

Il meccanismo si basa su un'asimmetria voluta tra trasmissione e ricezione:

- Il **trasmettitore** invia un frame preceduto da un **preambolo molto lungo** (molto più lungo del periodo di sleep del ricevitore).
- Il **ricevitore** attiva la propria radio **periodicamente e brevemente** per verificare se c'è un preambolo "nell'aria" (*preamble sampling*).
  - Se rileva un preambolo → mantiene la radio accesa e riceve il frame completo.
  - Altrimenti → spegne subito la radio e torna a dormire.

> **Regola fondamentale:** Il preambolo deve essere **più lungo del periodo di sleep** del ricevitore, altrimenti il ricevitore potrebbe "svegliarsi e riaddormentarsi" senza accorgersi del preambolo.

![Diagramma temporale B-MAC — Preamble sampling e ricezione frame](mac_notes_img/bmac_timing_diagram.png)
*Fig. 6 — Sequenza temporale B-MAC. Il mittente trasmette preambolo + frame. Il ricevitore campiona periodicamente: al primo campionamento non c'è nulla (sleep period), al secondo rileva il preambolo e rimane sveglio per ricevere il frame.*

### 3.2 Overhead del Low-Power Listening

Il preamble sampling non è gratuito: attivare e disattivare la radio ha un costo. Per la radio **Mica-Mote (CC1000)**, le fasi sono:

| Fase | Descrizione |
|------|-------------|
| **(a) sleep** | Radio spenta, consumo minimo |
| **(b) init** | Avvio su interrupt del timer |
| **(c) startup** | Inizializzazione e configurazione della radio |
| **(d) receive mode** | Entrata in modalità ricezione |
| **(e) receive signal** | Ricezione del segnale RF |
| **(f) decode** | Decodifica del segnale e analisi del frame |
| **(g) off** | Spegnimento radio |

![Consumo di corrente durante le fasi di LPL su Mica-Mote](mac_notes_img/bmac_lpl_overhead.png)
*Fig. 7 — Profilo di consumo di corrente durante un ciclo di preamble sampling su radio Mica-Mote. I picchi di corrente nelle fasi di startup e ricezione evidenziano il costo non trascurabile del campionamento.*

### 3.3 Modellazione della durata di vita

Per ottimizzare il duty cycle, è utile avere un modello analitico del consumo energetico. Definiamo:

| Simbolo | Significato |
|---------|-------------|
| $p_{tx}$ | Potenza in trasmissione |
| $p_{rx}$ | Potenza in ricezione |
| $p_{sleep}$ | Potenza in sleep |
| $t_{preamble}$ | Durata del preambolo |
| $t_{data}$ | Durata del frame dati |
| $t_{check}$ | Durata di un singolo campionamento LPL |
| $f_{data}$ | Frequenza di trasmissione dati (Hz) |
| $f_{check}$ | Frequenza di campionamento del preambolo (Hz) |

![Diagramma del modello energetico B-MAC — trasmettitore e ricevitore](mac_notes_img/bmac_modeling_diagram.png)
*Fig. 8 — Rappresentazione temporale del modello energetico. Il trasmettitore spende $E_{tx}$ per preambolo + dati. Il ricevitore spende in media la metà ($\frac{1}{2} t_{preamble}$ in ricezione) più il costo fisso dei check.*

**Duty cycle al trasmettitore:**
$$DC_{tx} = f_{data} \cdot (t_{preamble} + t_{data})$$
$$DC_{check,tx} = f_{check} \cdot t_{check}$$

**Energia spesa dal trasmettitore in $t$ secondi:**
$$ET(t) = t \cdot \left[ p_{tx} \cdot DC_{tx} + p_{rx} \cdot DC_{check} + p_{sleep} \cdot (1 - DC_{tx} - DC_{check}) \right]$$

**Duty cycle al ricevitore** (in media, attende metà del preambolo prima di rilevarlo):
$$DC_{rec} = f_{data} \cdot \left(\frac{1}{2} t_{preamble} + t_{data}\right)$$

**Energia spesa dal ricevitore in $t$ secondi:**
$$ER(t) = t \cdot \left[ p_{rx} \cdot DC_{rec} + p_{rx} \cdot DC_{check} + p_{sleep} \cdot (1 - DC_{rec} - DC_{check}) \right]$$

**Durata di vita:**
$$\text{lifetime} = \frac{\text{battery\_charge}}{ET(1)} \quad \text{(trasmettitore)}$$
$$\text{lifetime} = \frac{\text{battery\_charge}}{ER(1)} \quad \text{(ricevitore)}$$

**Parametri reali della radio CC1000 (dal paper originale B-MAC):**

![Tabella parametri radio CC1000 per B-MAC](mac_notes_img/bmac_params_table.png)
*Fig. 9 — Parametri reali della radio CC1000 usati nel modello B-MAC. Notare come il preambolo (271 bytes ≈ 0.113 s) sia molto più lungo del frame dati (36 bytes ≈ 0.015 s).*

**Grafici di lifetime:**

![Lifetime del trasmettitore vs check interval](mac_notes_img/bmac_lifetime_tx.png)
*Fig. 10 — Durata di vita del trasmettitore in funzione del check interval (con batteria da 3000 mAh). Ogni curva rappresenta una diversa frequenza di campionamento dati. Esiste un **check interval ottimale** che massimizza la durata di vita.*

![Lifetime del ricevitore vs check interval](mac_notes_img/bmac_lifetime_rx.png)
*Fig. 11 — Durata di vita del ricevitore. Analoga al trasmettitore ma con un range di check interval ottimale più ampio (la curva è più piatta).*

![Lifetime dei nodi con B-MAC al variare dei trasmettitori](mac_notes_img/bmac_node_lifetime.png)
*Fig. 12 — Lifetime dei nodi con più trasmettitori. Ogni curva corrisponde a una diversa frequenza di campionamento. I cerchi indicano il check interval ottimale per ciascuna frequenza. Con traffic maggiore (1 campione/min) il lifetime si riduce drasticamente.*

**Osservazione chiave:** Aumentare troppo il check interval allunga la trasmissione del preambolo (deve essere almeno pari al periodo di sleep), aumentando il consumo del trasmettitore. Esiste quindi un **punto ottimale** di trade-off.

### 3.4 Punti di forza e debolezze

**✅ Vantaggi:**
- Non è un protocollo di organizzazione della rete (non modifica la topologia).
- Semplicissimo da configurare: un solo parametro ($t_{check}$).
- Trasparente ai livelli superiori dello stack protocollare.

**⚠️ Svantaggi:**
- Check interval lunghi → preamboli lunghi → trasmissioni costose.
- Con traffico intenso, il costo del preamble sampling diventa non trascurabile.
- In alcuni scenari può risultare meno efficiente della sincronizzazione.

---

## 4. Evoluzione di B-MAC: X-MAC e BoX-MAC

### 4.1 X-MAC

**X-MAC** è la prima evoluzione di B-MAC, nata per ridurre il problema dei preamboli lunghi. L'idea chiave è permettere al ricevitore di **interrompere anticipatamente il preambolo**.

Il meccanismo:
- Il preambolo contiene l'**ID del ricevitore destinatario**.
- Quando il ricevitore campiona il canale e trova un preambolo, controlla se l'ID corrisponde al suo.
- Se sì → invia un **ACK anticipato** che interrompe il preambolo e richiede direttamente il frame dati.

![Confronto temporale B-MAC vs X-MAC](mac_notes_img/xmac_timing_diagram.png)
*Fig. 13 — Confronto B-MAC (in alto) vs X-MAC (in basso). In B-MAC il ricevitore aspetta passivamente l'intera trasmissione (lunga). In X-MAC il ricevitore invia un early ACK non appena riconosce il proprio ID, risparmiando tempo e energia sia al mittente (S) che al ricevitore (R).*

![Simulazione duty cycle totale X-MAC vs B-MAC](mac_notes_img/xmac_vs_bmac_graph.png)
*Fig. 14 — Duty cycle totale dei trasmettitori in una rete a stella (1 ricevitore, N trasmettitori), al variare del numero di trasmettitori e del check interval LPL. X-MAC (linee tratteggiata) ottiene sistematicamente duty cycle inferiori rispetto a B-MAC (linee continue) per ogni configurazione.*

### 4.2 BoX-MAC

**BoX-MAC** (*Backoff X-MAC*) è un'ulteriore evoluzione, che ottimizza il meccanismo in modo ancora più radicale. L'innovazione consiste nel far sì che il **preambolo stesso sia composto da ripetizioni del frame dati reale**.

Funzionamento:
1. Il trasmettitore invia ripetutamente il **frame dati completo** come "preambolo".
2. Il ricevitore, al suo campionamento periodico, aspetta il **prossimo header del frame**.
3. Se è il destinatario, **riceve il frame** e invia un **ACK** per fermare il trasmettitore.
4. Il trasmettitore smette di trasmettere non appena riceve l'ACK.

> 💡 Questo approccio **elimina la distinzione** tra preambolo e dati: il preambolo *è* già il dato. Funziona bene con **frame piccoli**.

![Diagramma temporale BoX-MAC — Sender e Receiver](mac_notes_img/boxmac_timing.png)
*Fig. 15 — Timing BoX-MAC. Il sender ripete il frame dati (verde) intervallato da check interval. Il receiver si sveglia, riceve uno dei frame ripetuti, invia ACK. Il sender si ferma appena riceve l'ACK.*

**Routing multi-hop in BoX-MAC:**

![Routing multi-hop BoX-MAC — tre nodi i1, i2, i3](mac_notes_img/boxmac_multihop.png)
*Fig. 16 — Routing multi-hop in BoX-MAC. Ogni nodo (i1, i2, i3) agisce da relay: riceve il frame durante il proprio check interval e inizia a ritrasmettere. Il DUTY_ON_TIME indica la finestra temporale in cui ogni nodo è attivo.*

---

## 5. Polling

Il **polling** è un meccanismo usato da **Bluetooth** e da **IEEE 802.15.4** (in combinazione con altri metodi). A differenza dei protocolli precedenti, polling introduce un'**organizzazione asimmetrica** della rete:

- Un nodo **master** emette **beacon periodici** (segnali di sincronizzazione e annuncio).
- I nodi **slave** possono tenere la radio spenta liberamente.

**Flusso di comunicazione Master → Slave:**

```
1. Il master riceve un messaggio destinato allo slave X
2. Il master conserva il messaggio in un buffer
3. Il master inserisce nel prossimo beacon: "c'è un messaggio per X"
4. Lo slave X si sveglia periodicamente e ascolta il beacon
5. Lo slave X riconosce il suo ID nel beacon
6. Lo slave X richiede il messaggio al master
7. Il master consegna il messaggio
```

Questo approccio trasferisce la complessità di gestione dell'energia dal protocollo di accesso al mezzo alla **struttura gerarchica** della rete (master/slave). È efficace in topologie a stella, tipiche di Bluetooth e delle reti IEEE 802.15.4 con coordinator.

---

## 6. Esercizi e Domande

### Domanda 1 — Debolezza di B-MAC
> *Un punto debole di B-MAC sono i preamboli molto lunghi. Come è possibile ridurli?*

**Risposta:** La soluzione è esattamente quella adottata da X-MAC: inserire nel preambolo l'**ID del destinatario** (come short preamble ripetuto). Quando il ricevitore campiona e riconosce il proprio ID, interrompe subito il preambolo inviando un early ACK. Non è necessario attendere la fine del preambolo originale. BoX-MAC porta questa idea all'estremo, facendo del frame dati stesso il "preambolo".

---

### Esercizio — Duty cycle B-MAC
> *La radio di un dispositivo B-MAC impiega $t_{check} = 4.0 \times 10^{-4}$ s per campionare il preambolo. La frequenza di campionamento è $f_{check} = 5$ Hz (5 volte al secondo). Calcola il duty cycle dell'attività di preamble sampling.*

**Soluzione:**
$$DC_{check} = f_{check} \cdot t_{check} = 5 \times 4.0 \times 10^{-4} = 2.0 \times 10^{-3} = 0.2\%$$

Il duty cycle del solo preamble sampling è lo **0.2%** — molto basso, il che giustifica l'efficienza di B-MAC quando il traffico è moderato.

---

## 7. Riferimenti bibliografici

- **S-MAC:** W. Ye, J. Heidemann, D. Estrin, *Medium access control with coordinated adaptive sleeping for wireless sensor networks*, IEEE/ACM Transactions on Networking 12(3), 2004, pp. 493–506.

- **B-MAC:** J. Polastre, J. Hill, D. Culler, *Versatile Low Power Media Access for Wireless Sensor Networks*, Proc. 2nd Int. Conf. on Embedded Networked Sensor Systems, Baltimore, MD, USA, Nov. 2004, pp. 95–107.

- **X-MAC:** M. Buettner, G.V. Yee, E. Anderson, R. Han, *X-MAC: A Short Preamble MAC Protocol for Duty-Cycled Wireless Sensor Networks*, Proc. 4th Int. Conf. on Embedded Networked Sensor Systems, Boulder, CO, USA, Oct–Nov 2006, pp. 307–320.

- **BoX-MAC:** D. Moss, P. Levis, *BoX-MACs: Exploiting Physical and Link Layer Boundaries in Low-Power Networking*, Technical Report, Stanford University, 2008.

---

*Appunti generati dalle slide del corso — Mobile and Cyber-Physical Systems, Prof. Stefano Chessa*
